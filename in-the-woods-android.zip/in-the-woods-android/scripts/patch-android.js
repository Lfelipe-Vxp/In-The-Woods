// Rode depois de "npx cap add android": deixa o app em modo horizontal e em tela cheia.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..', 'android', 'app', 'src', 'main');
const mf = path.join(root, 'AndroidManifest.xml');
let x = fs.readFileSync(mf, 'utf8');
if (!x.includes('screenOrientation')) {
  x = x.replace('<activity', '<activity\n            android:screenOrientation="sensorLandscape"');
  fs.writeFileSync(mf, x);
  console.log('OK: orientacao horizontal aplicada');
}
function find(d) {
  for (const f of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, f.name);
    if (f.isDirectory()) { const r = find(p); if (r) return r; }
    else if (f.name === 'MainActivity.java') return p;
  }
}
const ma = find(path.join(root, 'java'));
if (ma) {
  const src = fs.readFileSync(ma, 'utf8');
  const pkg = (src.match(/^package\s+([\w.]+);/m) || [])[1];
  fs.writeFileSync(ma, `package ${pkg};

import com.getcapacitor.BridgeActivity;
import android.view.View;

public class MainActivity extends BridgeActivity {
  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) {
      getWindow().getDecorView().setSystemUiVisibility(
        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }
  }
}
`);
  console.log('OK: tela cheia aplicada');
}
